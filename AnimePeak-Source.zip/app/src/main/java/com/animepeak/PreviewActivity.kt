package com.animepeak

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class PreviewActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val query = intent.getStringExtra("query") ?: "epic anime scenes"
        val titleText = intent.getStringExtra("title") ?: "Anime moment"
        val videoId = intent.getStringExtra("video_id").orEmpty()
        val target = if (videoId.isNotBlank()) {
            "https://www.youtube.com/watch?v=$videoId"
        } else {
            "https://www.youtube.com/results?search_query=${Uri.encode(query)}"
        }

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF10101A.toInt())
        }
        box.addView(TextView(this).apply {
            text = titleText
            textSize = 18f
            setTextColor(-1)
            gravity = Gravity.CENTER_VERTICAL
            setPadding(16, 12, 16, 12)
        })
        box.addView(WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            webViewClient = WebViewClient()
            loadUrl(target)
        }, LinearLayout.LayoutParams(-1, 0, 1f))
        box.addView(Button(this).apply {
            text = "Open in YouTube"
            setOnClickListener {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(target)))
            }
        })
        setContentView(box)
    }
}
