package com.animepeak
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import androidx.work.Worker
import androidx.work.WorkerParameters
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class SceneRefreshWorker(context: Context, params: WorkerParameters) : Worker(context, params) {
    override fun doWork(): Result {
        val ctx = applicationContext
        val prefs = ctx.getSharedPreferences("anime_peak", Context.MODE_PRIVATE)
        val index = (prefs.getInt("curated_index", -1) + 1) % AnimeData.curated.size
        var moment = AnimeData.curated[index]
        val apiKey = prefs.getString("youtube_api_key", "") ?: ""
        if (apiKey.isNotBlank()) {
            try {
                val q = URLEncoder.encode(moment.query, "UTF-8")
                val url = URL("https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&maxResults=1&q=$q&key=$apiKey")
                val conn = (url.openConnection() as HttpURLConnection).apply { connectTimeout = 7000; readTimeout = 7000 }
                val json = conn.inputStream.bufferedReader().use { it.readText() }
                conn.disconnect()
                val item = JSONObject(json).optJSONArray("items")?.optJSONObject(0)
                val foundTitle = item?.optJSONObject("snippet")?.optString("title")
                if (!foundTitle.isNullOrBlank()) moment = AnimeMoment(foundTitle, moment.query)
            } catch (_: Exception) { }
        }
        prefs.edit().putInt("curated_index", index).putString("scene_title", moment.title)
            .putString("scene_query", moment.query).apply()
        val manager = AppWidgetManager.getInstance(ctx)
        val ids = manager.getAppWidgetIds(ComponentName(ctx, AnimeWidgetProvider::class.java))
        ids.forEach { AnimeWidgetProvider.update(ctx, manager, it) }
        return Result.success()
    }
}
