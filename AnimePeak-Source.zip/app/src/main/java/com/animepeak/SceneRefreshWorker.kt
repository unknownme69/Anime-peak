package com.animepeak

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.work.Worker
import androidx.work.WorkerParameters
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class SceneRefreshWorker(context: Context, params: WorkerParameters) : Worker(context, params) {
    override fun doWork(): Result {
        val ctx = applicationContext
        // Work is useful only while at least one home-screen widget exists.
        // This also protects against a queued job running after widget removal.
        if (!AnimeWidgetProvider.hasWidgets(ctx)) return Result.success()
        val prefs = ctx.getSharedPreferences("anime_peak", Context.MODE_PRIVATE)
        val index = (prefs.getInt("curated_index", -1) + 1) % AnimeData.curated.size
        val moment = AnimeData.curated[index]
        val apiKey = prefs.getString("youtube_api_key", "")?.trim().orEmpty()

        if (apiKey.isBlank()) {
            // If a key is temporarily absent, keep the cached scene library usable.
            if (rotateLibrary(ctx)) return Result.success()
            return Result.success()
        }

        var connection: HttpURLConnection? = null
        try {
            val query = URLEncoder.encode(moment.query, "UTF-8")
            val endpoint = URL(
                "https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&maxResults=1&safeSearch=none&q=$query&key=$apiKey"
            )
            connection = (endpoint.openConnection() as HttpURLConnection).apply {
                connectTimeout = 12000
                readTimeout = 12000
                requestMethod = "GET"
            }

            if (connection.responseCode !in 200..299) {
                connection.disconnect()
                if (rotateLibrary(ctx)) return Result.success()
                return Result.retry()
            }

            val json = connection.inputStream.bufferedReader().use { it.readText() }
            val item = JSONObject(json).optJSONArray("items")?.optJSONObject(0)
            val snippet = item?.optJSONObject("snippet")
            val videoId = item?.optJSONObject("id")?.optString("videoId").orEmpty()
            val title = snippet?.optString("title").orEmpty()
            val thumbs = snippet?.optJSONObject("thumbnails")
            val thumbUrl = thumbs?.optJSONObject("maxres")?.optString("url").orEmpty()
                .ifBlank { thumbs?.optJSONObject("high")?.optString("url").orEmpty() }
                .ifBlank { thumbs?.optJSONObject("medium")?.optString("url").orEmpty() }
                .ifBlank { thumbs?.optJSONObject("default")?.optString("url").orEmpty() }

            if (videoId.isNotBlank() && thumbUrl.isNotBlank()) {
                val bitmap = downloadBitmap(thumbUrl)
                if (bitmap != null) {
                    val imageName = "anime_scene_${videoId}.jpg"
                    val imageFile = File(ctx.filesDir, imageName)
                    imageFile.outputStream().use { out ->
                        bitmap.compress(Bitmap.CompressFormat.JPEG, 88, out)
                    }
                    bitmap.recycle()
                    saveToLibrary(ctx, title.ifBlank { moment.title }, moment.query, videoId, imageName)
                    prefs.edit()
                        .putInt("curated_index", index)
                        .putString("scene_title", title.ifBlank { moment.title })
                        .putString("scene_query", moment.query)
                        .putString("scene_video_id", videoId)
                        .putString("scene_file", imageName)
                        .apply()
                }
            }
        } catch (_: Exception) {
            // Reuse a previously discovered scene instead of blanking the widget.
            if (rotateLibrary(ctx)) return Result.success()
            return Result.retry()
        } finally {
            connection?.disconnect()
        }

        refreshWidgets(ctx)
        return Result.success()
    }

    private fun downloadBitmap(url: String): Bitmap? {
        var conn: HttpURLConnection? = null
        return try {
            conn = (URL(url).openConnection() as HttpURLConnection).apply {
                connectTimeout = 12000
                readTimeout = 12000
            }
            if (conn.responseCode in 200..299) {
                // YouTube max-resolution thumbnails are often 1280x720. A half-size
                // decode is still crisp in a phone widget and uses about 1/4 the RAM.
                val options = BitmapFactory.Options().apply {
                    inSampleSize = 2
                    inPreferredConfig = Bitmap.Config.RGB_565
                }
                conn.inputStream.use { BitmapFactory.decodeStream(it, null, options) }
            } else null
        } catch (_: Exception) {
            null
        } finally {
            conn?.disconnect()
        }
    }


    private fun saveToLibrary(
        context: Context, title: String, query: String, videoId: String, fileName: String
    ) {
        val prefs = context.getSharedPreferences("anime_peak", Context.MODE_PRIVATE)
        val old = runCatching { JSONArray(prefs.getString("scene_library", "[]")) }
            .getOrElse { JSONArray() }
        val updated = JSONArray()
        // Keep newest entries first and avoid storing the same video twice.
        updated.put(JSONObject().put("title", title).put("query", query)
            .put("video_id", videoId).put("file", fileName))
        for (i in 0 until old.length()) {
            val item = old.optJSONObject(i) ?: continue
            if (item.optString("video_id") == videoId) continue
            if (updated.length() >= MAX_LIBRARY_SIZE) break
            updated.put(item)
        }
        val keep = HashSet<String>()
        for (i in 0 until updated.length()) keep.add(updated.getJSONObject(i).optString("file"))
        context.filesDir.listFiles()?.filter { it.name.startsWith("anime_scene_") && it.name.endsWith(".jpg") }
            ?.forEach { if (it.name !in keep) it.delete() }
        prefs.edit().putString("scene_library", updated.toString()).apply()
    }

    private fun rotateLibrary(context: Context): Boolean {
        val prefs = context.getSharedPreferences("anime_peak", Context.MODE_PRIVATE)
        val library = runCatching { JSONArray(prefs.getString("scene_library", "[]")) }
            .getOrElse { JSONArray() }
        if (library.length() == 0) return false
        val current = prefs.getString("scene_video_id", "").orEmpty()
        var selected: JSONObject? = null
        for (offset in 1..library.length()) {
            val item = library.optJSONObject(offset % library.length()) ?: continue
            val file = File(context.filesDir, item.optString("file"))
            if (file.exists() && item.optString("video_id") != current) {
                selected = item
                break
            }
        }
        if (selected == null) selected = library.optJSONObject(0)
        val item = selected ?: return false
        val fileName = item.optString("file")
        if (!File(context.filesDir, fileName).exists()) return false
        prefs.edit()
            .putString("scene_title", item.optString("title"))
            .putString("scene_query", item.optString("query"))
            .putString("scene_video_id", item.optString("video_id"))
            .putString("scene_file", fileName)
            .apply()
        refreshWidgets(context)
        return true
    }

    companion object {
        private const val MAX_LIBRARY_SIZE = 24
    }
    private fun refreshWidgets(context: Context) {
        val manager = AppWidgetManager.getInstance(context)
        val ids = manager.getAppWidgetIds(ComponentName(context, AnimeWidgetProvider::class.java))
        ids.forEach { AnimeWidgetProvider.update(context, manager, it) }
    }
}
