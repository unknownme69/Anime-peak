package com.animepeak

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.work.Worker
import androidx.work.WorkerParameters
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class SceneRefreshWorker(context: Context, params: WorkerParameters) : Worker(context, params) {
    override fun doWork(): Result {
        val ctx = applicationContext
        val prefs = ctx.getSharedPreferences("anime_peak", Context.MODE_PRIVATE)
        val index = (prefs.getInt("curated_index", -1) + 1) % AnimeData.curated.size
        val moment = AnimeData.curated[index]
        val apiKey = prefs.getString("youtube_api_key", "")?.trim().orEmpty()

        if (apiKey.isBlank()) {
            prefs.edit()
                .putInt("curated_index", index)
                .putString("scene_title", "Add your YouTube API key to load real anime images")
                .putString("scene_query", moment.query)
                .putString("scene_video_id", "")
                .apply()
            refreshWidgets(ctx)
            return Result.success()
        }

        var connection: HttpURLConnection? = null
        try {
            val query = URLEncoder.encode(moment.query, "UTF-8")
            val endpoint = URL(
                "https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&maxResults=1&safeSearch=none&q=$query&key=$apiKey"
            )
            connection = (endpoint.openConnection() as HttpURLConnection).apply {
                connectTimeout = 12000
                readTimeout = 12000
                requestMethod = "GET"
            }

            if (connection.responseCode !in 200..299) {
                connection.disconnect()
                refreshWidgets(ctx)
                return Result.retry()
            }

            val json = connection.inputStream.bufferedReader().use { it.readText() }
            val item = JSONObject(json).optJSONArray("items")?.optJSONObject(0)
            val snippet = item?.optJSONObject("snippet")
            val videoId = item?.optJSONObject("id")?.optString("videoId").orEmpty()
            val title = snippet?.optString("title").orEmpty()
            val thumbs = snippet?.optJSONObject("thumbnails")
            val thumbUrl = thumbs?.optJSONObject("maxres")?.optString("url").orEmpty()
                .ifBlank { thumbs?.optJSONObject("high")?.optString("url").orEmpty() }
                .ifBlank { thumbs?.optJSONObject("medium")?.optString("url").orEmpty() }
                .ifBlank { thumbs?.optJSONObject("default")?.optString("url").orEmpty() }

            if (videoId.isNotBlank() && thumbUrl.isNotBlank()) {
                val bitmap = downloadBitmap(thumbUrl)
                if (bitmap != null) {
                    val imageFile = File(ctx.filesDir, "scene_thumbnail.jpg")
                    imageFile.outputStream().use { out ->
                        bitmap.compress(Bitmap.CompressFormat.JPEG, 92, out)
                    }
                    bitmap.recycle()
                    prefs.edit()
                        .putInt("curated_index", index)
                        .putString("scene_title", title.ifBlank { moment.title })
                        .putString("scene_query", moment.query)
                        .putString("scene_video_id", videoId)
                        .apply()
                }
            }
        } catch (_: Exception) {
            // Preserve the last downloaded thumbnail if the network/API is temporarily unavailable.
            return Result.retry()
        } finally {
            connection?.disconnect()
        }

        refreshWidgets(ctx)
        return Result.success()
    }

    private fun downloadBitmap(url: String): Bitmap? {
        var conn: HttpURLConnection? = null
        return try {
            conn = (URL(url).openConnection() as HttpURLConnection).apply {
                connectTimeout = 12000
                readTimeout = 12000
            }
            if (conn.responseCode in 200..299) {
                conn.inputStream.use { BitmapFactory.decodeStream(it) }
            } else null
        } catch (_: Exception) {
            null
        } finally {
            conn?.disconnect()
        }
    }

    private fun refreshWidgets(context: Context) {
        val manager = AppWidgetManager.getInstance(context)
        val ids = manager.getAppWidgetIds(ComponentName(context, AnimeWidgetProvider::class.java))
        ids.forEach { AnimeWidgetProvider.update(context, manager, it) }
    }
}
