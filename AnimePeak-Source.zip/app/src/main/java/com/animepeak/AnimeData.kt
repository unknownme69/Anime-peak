package com.animepeak

data class AnimeMoment(val title: String, val query: String)

object AnimeData {
    val curated = listOf(
        AnimeMoment("I AM ATOMIC — The Eminence in Shadow", "The Eminence in Shadow Cid I AM ATOMIC anime scene"),
        AnimeMoment("Jinwoo commands the shadow army", "Solo Leveling Sung Jinwoo arise shadow army anime scene"),
        AnimeMoment("Rimuru's awakening", "That Time I Got Reincarnated as a Slime Rimuru awakening anime scene"),
        AnimeMoment("Ainz reveals his overwhelming power", "Overlord Ainz Ooal Gown powerful magic anime scene"),
        AnimeMoment("A legendary anime entrance", "anime iconic character entrance actual scene"),
        AnimeMoment("The final blow", "anime epic finishing move actual episode scene"),
        AnimeMoment("The hidden power is unleashed", "anime hidden power reveal actual episode scene"),
        AnimeMoment("A battlefield-changing transformation", "anime transformation battle actual episode scene"),
        AnimeMoment("An impossible counterattack", "anime epic counterattack actual episode scene"),
        AnimeMoment("The strongest arrives", "anime strongest character arrives actual scene")
    )
}
