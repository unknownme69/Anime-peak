package com.animepeak
data class AnimeMoment(val title: String, val query: String)
object AnimeData {
    val curated = listOf(
        AnimeMoment("When the hero finally stops holding back", "anime hero stops holding back best scene"),
        AnimeMoment("A transformation that changes the whole battle", "best anime transformation scene"),
        AnimeMoment("The villain makes an unforgettable entrance", "best anime villain entrance scene"),
        AnimeMoment("An impossible comeback", "best anime comeback fight scene"),
        AnimeMoment("The quiet character reveals their true power", "anime hidden power reveal scene"),
        AnimeMoment("A legendary final clash", "best animated anime final battle"),
        AnimeMoment("The battlefield goes completely silent", "anime intimidating aura scene"),
        AnimeMoment("A perfectly timed counterattack", "anime epic counterattack moment"),
        AnimeMoment("An overpowered character arrives", "overpowered anime character entrance"),
        AnimeMoment("The moment everything changes", "anime most hype moment scene")
    )
}
