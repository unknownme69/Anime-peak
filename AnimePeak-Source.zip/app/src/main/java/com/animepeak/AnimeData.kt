package com.animepeak

data class AnimeMoment(val title: String, val query: String)

object AnimeData {
    // Search focus: action, fantasy, isekai and overwhelming-power moments.
    // Queries deliberately target real scene clips rather than AI image content.
    val curated = listOf(
        AnimeMoment("I AM ATOMIC", "The Eminence in Shadow Cid I AM ATOMIC anime scene official clip"),
        AnimeMoment("Shadow Army", "Solo Leveling Sung Jinwoo arise shadow army anime scene official clip"),
        AnimeMoment("Rimuru Awakening", "That Time I Got Reincarnated as a Slime Rimuru awakening anime scene"),
        AnimeMoment("Ainz Overwhelming Magic", "Overlord Ainz Ooal Gown powerful magic anime scene"),
        AnimeMoment("Anos Voldigoad", "The Misfit of Demon King Academy Anos power reveal anime scene"),
        AnimeMoment("Cid's Hidden Power", "The Eminence in Shadow Cid powerful battle anime scene"),
        AnimeMoment("Sung Jinwoo's Power", "Solo Leveling Sung Jinwoo powerful fight anime scene"),
        AnimeMoment("The Strongest Arrives", "overpowered fantasy anime character entrance actual scene"),
        AnimeMoment("A Legendary Transformation", "isekai fantasy anime transformation battle scene"),
        AnimeMoment("The Final Blow", "fantasy anime epic finishing move actual episode scene"),
        AnimeMoment("A Battlefield Turns", "overpowered anime character changes battlefield scene"),
        AnimeMoment("An Impossible Counter", "fantasy anime epic counterattack actual scene"),
        AnimeMoment("The Hidden Skill", "isekai anime hidden ability reveal actual scene"),
        AnimeMoment("A Demon Lord's Arrival", "demon lord anime entrance powerful scene"),
        AnimeMoment("A Legendary Spell", "fantasy anime strongest magic spell scene")
    )
}
