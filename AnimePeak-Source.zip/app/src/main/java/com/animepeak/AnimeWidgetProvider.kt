package com.animepeak

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.view.View
import android.widget.RemoteViews
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import java.io.File

class AnimeWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { update(context, manager, it) }
        AnimeRefreshScheduler.schedule(context)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_REFRESH) {
            WorkManager.getInstance(context)
                .enqueue(OneTimeWorkRequestBuilder<SceneRefreshWorker>().build())
        }
    }

    companion object {
        const val ACTION_REFRESH = "com.animepeak.REFRESH"

        fun update(context: Context, manager: AppWidgetManager, id: Int) {
            val prefs = context.getSharedPreferences("anime_peak", Context.MODE_PRIVATE)
            val title = prefs.getString(
                "scene_title", "Add a YouTube API key for real anime images"
            ) ?: "Add a YouTube API key for real anime images"
            val query = prefs.getString("scene_query", AnimeData.curated[0].query)
                ?: AnimeData.curated[0].query
            val videoId = prefs.getString("scene_video_id", "").orEmpty()

            val views = RemoteViews(context.packageName, R.layout.anime_widget)
            views.setTextViewText(R.id.widget_scene, title)

            val imageFile = File(context.filesDir, "scene_thumbnail.jpg")
            if (imageFile.exists()) {
                val bitmap = BitmapFactory.decodeFile(imageFile.absolutePath)
                if (bitmap != null) {
                    views.setImageViewBitmap(R.id.widget_scene_image, bitmap)
                    views.setViewVisibility(R.id.widget_scene_image, View.VISIBLE)
                    views.setViewVisibility(R.id.widget_image_hint, View.GONE)
                }
            } else {
                views.setViewVisibility(R.id.widget_scene_image, View.GONE)
                views.setViewVisibility(R.id.widget_image_hint, View.VISIBLE)
            }

            val open = Intent(context, PreviewActivity::class.java)
                .putExtra("query", query)
                .putExtra("title", title)
                .putExtra("video_id", videoId)
            val openPending = PendingIntent.getActivity(
                context, id + 10, open,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_scene_image, openPending)
            views.setOnClickPendingIntent(R.id.widget_scene, openPending)
            views.setOnClickPendingIntent(R.id.widget_watch, openPending)

            val refresh = Intent(context, AnimeWidgetProvider::class.java).setAction(ACTION_REFRESH)
            views.setOnClickPendingIntent(
                R.id.widget_refresh,
                PendingIntent.getBroadcast(
                    context, id + 20, refresh,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
            )
            manager.updateAppWidget(id, views)
        }
    }
}
