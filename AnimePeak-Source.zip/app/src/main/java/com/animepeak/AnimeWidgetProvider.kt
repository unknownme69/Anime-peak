package com.animepeak
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager

class AnimeWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { update(context, manager, it) }
        AnimeRefreshScheduler.schedule(context)
    }
    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_REFRESH) {
            WorkManager.getInstance(context).enqueue(OneTimeWorkRequestBuilder<SceneRefreshWorker>().build())
        }
    }
    companion object {
        const val ACTION_REFRESH = "com.animepeak.REFRESH"
        fun update(context: Context, manager: AppWidgetManager, id: Int) {
            val prefs = context.getSharedPreferences("anime_peak", Context.MODE_PRIVATE)
            val title = prefs.getString("scene_title", AnimeData.curated[0].title) ?: AnimeData.curated[0].title
            val query = prefs.getString("scene_query", AnimeData.curated[0].query) ?: AnimeData.curated[0].query
            val views = RemoteViews(context.packageName, R.layout.anime_widget)
            views.setTextViewText(R.id.widget_scene, title)
            val open = Intent(context, PreviewActivity::class.java).putExtra("query", query).putExtra("title", title)
            views.setOnClickPendingIntent(R.id.widget_watch, PendingIntent.getActivity(
                context, id + 10, open, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
            val refresh = Intent(context, AnimeWidgetProvider::class.java).setAction(ACTION_REFRESH)
            views.setOnClickPendingIntent(R.id.widget_refresh, PendingIntent.getBroadcast(
                context, id + 20, refresh, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
            manager.updateAppWidget(id, views)
        }
    }
}
