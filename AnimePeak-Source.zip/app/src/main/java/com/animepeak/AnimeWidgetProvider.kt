package com.animepeak

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.widget.RemoteViews
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import java.io.File

class AnimeWidgetProvider : AppWidgetProvider() {
    override fun onEnabled(context: Context) {
        // Called when the first widget is added.
        AnimeRefreshScheduler.schedule(context)
    }

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { update(context, manager, it) }
        AnimeRefreshScheduler.schedule(context)
    }

    override fun onDeleted(context: Context, appWidgetIds: IntArray) {
        super.onDeleted(context, appWidgetIds)
        if (!hasWidgets(context)) AnimeRefreshScheduler.cancel(context)
    }

    override fun onDisabled(context: Context) {
        // Last widget removed: stop all periodic work.
        AnimeRefreshScheduler.cancel(context)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_REFRESH && hasWidgets(context)) {
            WorkManager.getInstance(context)
                .enqueue(OneTimeWorkRequestBuilder<SceneRefreshWorker>().build())
        }
    }

    companion object {
        const val ACTION_REFRESH = "com.animepeak.REFRESH"

        fun hasWidgets(context: Context): Boolean {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(
                ComponentName(context, AnimeWidgetProvider::class.java)
            )
            return ids.isNotEmpty()
        }

        fun update(context: Context, manager: AppWidgetManager, id: Int) {
            val prefs = context.getSharedPreferences("anime_peak", Context.MODE_PRIVATE)
            val query = prefs.getString("scene_query", AnimeData.curated[0].query)
                ?: AnimeData.curated[0].query
            val title = prefs.getString("scene_title", "Anime scene") ?: "Anime scene"
            val videoId = prefs.getString("scene_video_id", "").orEmpty()

            val views = RemoteViews(context.packageName, R.layout.anime_widget)
            val imageName = prefs.getString("scene_file", "scene_thumbnail.jpg")
                ?: "scene_thumbnail.jpg"
            val imageFile = File(context.filesDir, imageName)
            if (imageFile.exists()) {
                // Keep the bitmap small before placing it in RemoteViews. This avoids
                // decoding a full 1280px thumbnail every time Android redraws the widget.
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeFile(imageFile.absolutePath, bounds)
                val sample = if (bounds.outWidth > 720 || bounds.outHeight > 720) 2 else 1
                val options = BitmapFactory.Options().apply { inSampleSize = sample }
                val bitmap = BitmapFactory.decodeFile(imageFile.absolutePath, options)
                if (bitmap != null) views.setImageViewBitmap(R.id.widget_scene_image, bitmap)
            }

            val open = Intent(context, PreviewActivity::class.java)
                .putExtra("query", query)
                .putExtra("title", title)
                .putExtra("video_id", videoId)
            val openPending = PendingIntent.getActivity(
                context, id + 10, open,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_scene_image, openPending)

            val refresh = Intent(context, AnimeWidgetProvider::class.java).setAction(ACTION_REFRESH)
            views.setOnClickPendingIntent(
                R.id.widget_refresh,
                PendingIntent.getBroadcast(
                    context, id + 20, refresh,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
            )
            manager.updateAppWidget(id, views)
        }
    }
}
