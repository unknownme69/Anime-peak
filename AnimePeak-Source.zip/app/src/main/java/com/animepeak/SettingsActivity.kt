package com.animepeak
import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
class SettingsActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("anime_peak", MODE_PRIVATE)
        val box = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER_VERTICAL
            setPadding(24,24,24,24); setBackgroundColor(0xFF171522.toInt()) }
        box.addView(TextView(this).apply { text="YouTube discovery"; textSize=23f; setTextColor(-1) })
        box.addView(TextView(this).apply {
            text="Optional: enter a YouTube Data API v3 key to attempt fresh video-title discovery. Curated prompts work without a key."
            setTextColor(0xFFE5DDF2.toInt()); setPadding(0,12,0,16) })
        val key = EditText(this).apply { hint="YouTube API key (optional)"; setSingleLine(true)
            setText(prefs.getString("youtube_api_key","")) }
        box.addView(key)
        box.addView(Button(this).apply { text="Save key"; setOnClickListener {
            prefs.edit().putString("youtube_api_key", key.text.toString().trim()).apply(); finish() } })
        setContentView(box)
    }
}
