package com.animepeak

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

class SettingsActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("anime_peak", MODE_PRIVATE)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(24, 24, 24, 24)
            setBackgroundColor(0xFF171522.toInt())
        }

        box.addView(TextView(this).apply {
            text = "Real anime scene images"
            textSize = 23f
            setTextColor(-1)
        })
        box.addView(TextView(this).apply {
            text = "Anime Peak searches YouTube and displays the real thumbnail supplied for the selected video. These are not AI-generated images, but YouTube thumbnails can sometimes be promotional artwork or edited images rather than an exact episode frame. A YouTube Data API v3 key is required for automatic discovery."
            setTextColor(0xFFE5DDF2.toInt())
            setPadding(0, 12, 0, 16)
        })
        val key = EditText(this).apply {
            hint = "YouTube Data API v3 key"
            setSingleLine(true)
            setText(prefs.getString("youtube_api_key", ""))
        }
        box.addView(key)
        box.addView(Button(this).apply {
            text = "How to get an API key"
            setOnClickListener {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(
                    "https://console.cloud.google.com/apis/library/youtube.googleapis.com"
                )))
            }
        })
        box.addView(Button(this).apply {
            text = "Save key"
            setOnClickListener {
                prefs.edit().putString("youtube_api_key", key.text.toString().trim()).apply()
                finish()
            }
        })
        setContentView(box)
    }
}
