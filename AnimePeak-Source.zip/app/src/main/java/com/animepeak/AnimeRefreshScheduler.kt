package com.animepeak
import android.content.Context
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit
object AnimeRefreshScheduler {
    fun schedule(context: Context) {
        val request = PeriodicWorkRequestBuilder<SceneRefreshWorker>(15, TimeUnit.MINUTES).build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            "anime_peak_periodic_refresh", ExistingPeriodicWorkPolicy.UPDATE, request)
    }
}
