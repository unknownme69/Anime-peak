package com.animepeak

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 28, 28, 28)
            setBackgroundColor(0xFF171522.toInt())
        }
        box.addView(TextView(this).apply {
            text = "ANIME PEAK"
            textSize = 28f
            gravity = Gravity.CENTER
            setTextColor(-1)
        })
        box.addView(TextView(this).apply {
            text = "Real anime video thumbnails, rotating scene discovery, and one-tap access to the video. Add your YouTube API key to enable image discovery."
            textSize = 16f
            gravity = Gravity.CENTER
            setTextColor(0xFFE5DDF2.toInt())
            setPadding(0, 22, 0, 22)
        })
        box.addView(Button(this).apply {
            text = "Refresh scene"
            setOnClickListener {
                WorkManager.getInstance(this@MainActivity)
                    .enqueue(OneTimeWorkRequestBuilder<SceneRefreshWorker>().build())
            }
        })
        box.addView(Button(this).apply {
            text = "YouTube image settings"
            setOnClickListener {
                startActivity(Intent(this@MainActivity, SettingsActivity::class.java))
            }
        })
        setContentView(box)
    }
}
