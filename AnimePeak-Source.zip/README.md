# Anime Peak — visual upgrade (v1.1.0)

This source replaces the text-only widget with an image-first, resizable home-screen widget.

## Image source and limitations
Anime Peak uses YouTube Data API v3 to search videos and displays the thumbnail image supplied by the uploader. It does not generate AI images. However, YouTube thumbnails are not guaranteed to be literal episode screenshots: uploaders may use edited images, promotional artwork, or fan-made thumbnails. The app opens the selected YouTube video when tapped.

A YouTube Data API v3 key is required for automatic discovery and thumbnails. In the app, open **YouTube image settings**, use **How to get an API key**, enable YouTube Data API v3 in a Google Cloud project, create an API key, paste it into Anime Peak, and save.

The widget supports manual refresh and periodic refresh. Android WorkManager periodic work has a 15-minute minimum interval; it cannot reliably refresh every two minutes in the background.

## Build
Android Gradle Plugin 8.7.3, Gradle 8.9, Java/Kotlin JVM target 17.
