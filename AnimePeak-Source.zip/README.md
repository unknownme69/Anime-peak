# Anime Peak 1.2.0

Anime Peak is a lightweight Android home-screen widget focused on action, fantasy, isekai and overpowered-character anime moments.

## Widget
- Image-only widget: no titles, labels or buttons over the image.
- Small refresh icon in the top-right corner.
- Tap the image to open the matching YouTube video.
- Resizable, including compact home-screen sizes.

## Memory and background behavior
- No foreground service is used and the app does not keep a process running just to animate the widget.
- Periodic discovery is scheduled only while at least one widget exists.
- The periodic job is cancelled when the last widget is removed.
- Background refresh runs no more often than every six hours, only with a network connection and when the battery is not low.
- A queued worker exits immediately if the widget has since been removed.
- Thumbnail images are decoded at half resolution for widget display to reduce peak RAM use. The downloaded images remain on disk; bitmaps are not held in a long-lived service.
- The app keeps a small local library of up to 24 distinct discovered YouTube scenes and reuses cached scenes if a later discovery request fails.

Android does not expose a reliable general-purpose signal for whether a launcher widget is currently visible on-screen. This version therefore uses the safest practical approximation: no widget means no scheduled refresh; a widget exists means infrequent WorkManager refreshes. WorkManager may defer a refresh further according to Android battery and background rules.

## Image source
Anime Peak uses YouTube Data API v3 to search for real anime scene videos and displays the thumbnail supplied by the uploader. It does not generate AI images. YouTube thumbnails are not guaranteed to be literal episode screenshots; some may be promotional art, edited images or fan-made thumbnails. Tapping the image opens the corresponding YouTube video.

A YouTube Data API v3 key is required for automatic discovery. Open Anime Peak > YouTube image settings, paste the key and save it. The key is stored locally in app preferences.

## Build
Android Gradle Plugin 8.7.3, Gradle 8.9, Java/Kotlin JVM target 17, compile/target SDK 35, min SDK 26.
