# Anime Peak source
- 2×2 home-screen widget with curated rotating anime-moment prompts.
- Manual refresh control.
- Tap Discover to view a YouTube search for the current moment.
- Optional YouTube Data API v3 key setting for fresh video-title lookup; curated fallback remains if unavailable.
- WorkManager background refresh (Android's minimum periodic interval is 15 minutes).
- No root, bootloader unlock, or device modifications.

Note: Android home-screen widgets are not designed for continuous video playback. This starter shows a prompt in the widget and opens YouTube search in the companion screen. It is a starter source package and must be built/tested before installation.
